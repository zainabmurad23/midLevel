fetch("https://jsonplaceholder.typicode.com/users")
  .then(response => {
    if (!response.ok) {
      throw new Error("HTTP error: " + response.status);
    }
    return response.json();
  })
  .then(data => console.log(data))
  .catch(error => {
    if (error.message.startsWith("HTTP error")) {
      console.log(error.message);
    } else {
      console.log("Network error");
    }
  });

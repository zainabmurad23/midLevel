function loadUser() {
  const json = localStorage.getItem("user");

  if (json === null) {
    return null;
  }

  return JSON.parse(json);
}

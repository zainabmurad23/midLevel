const obj = { name: "Ali", age: 25 };
const formatted = JSON.stringify(obj, null, 2);

const preElement = document.createElement("pre");
preElement.textContent = formatted;

document.body.appendChild(preElement);

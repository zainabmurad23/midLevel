async function loadUserAndPosts() {
  try {

    const userRes = await fetch("https://jsonplaceholder.typicode.com/users/1");
    const user = await userRes.json();


    const postsRes = await fetch(
      `https://jsonplaceholder.typicode.com/posts?userId=${user.id}`
    );
    const posts = await postsRes.json();

 
    console.log("User:", user);
    console.log("Posts:", posts);
  } catch (error) {
    console.log("Error:", error);
  }
}

loadUserAndPosts();

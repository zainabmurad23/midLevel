fetch("https://jsonplaceholder.typicode.com/posts")
  .then(res => res.json())
  .then(posts => {
    const longTitles = posts.filter(post => post.title.length > 20);

    const ul = document.createElement("ul");

    longTitles.forEach(post => {
      const li = document.createElement("li");
      li.textContent = post.title;
      ul.appendChild(li);
    });

    document.body.appendChild(ul);
  })
  .catch(err => console.log("Error:", err));

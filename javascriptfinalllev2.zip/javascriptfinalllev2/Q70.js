function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function delayedMessage() {
  await wait(2000);
  return "Hello after 2 seconds";
}


delayedMessage().then(msg => console.log(msg));

function cloneObjectUsingJSON(obj) {
  return JSON.parse(JSON.stringify(obj));
}

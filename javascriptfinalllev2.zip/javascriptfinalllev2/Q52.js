fetch("https://jsonplaceholder.typicode.com/photos")
  .then(res => res.json())
  .then(photos => {
    const container = document.getElementById("photos");
    const firstTen = photos.slice(0, 10);

    firstTen.forEach(photo => {
      const img = document.createElement("img");
      img.src = photo.thumbnailUrl;
      img.alt = photo.title;
      img.style.margin = "5px";

      const caption = document.createElement("p");
      caption.textContent = photo.title;

      const wrapper = document.createElement("div");
      wrapper.appendChild(img);
      wrapper.appendChild(caption);

      container.appendChild(wrapper);
    });
  })
  .catch(err => console.log("Network error:", err));

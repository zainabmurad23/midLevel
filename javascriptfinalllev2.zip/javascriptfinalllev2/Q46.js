fetch("https://jsonplaceholder.typicode.com/users")
  .then(response => response.json())
  .then(users => {
    console.log("Number of users:", users.length);
    console.log("First user’s name:", users[0].name);
  })
  .catch(err => console.log("Network error:", err));

class Shape {
  area() {
    throw new Error("area() must be overridden");
  }
}

class Circle extends Shape {
  constructor(radius) {
    super();
    this.radius = radius;
  }
  area() {
    return Math.PI * this.radius * this.radius;
  }
}

class Rectangle extends Shape {
  constructor(w, h) {
    super();
    this.w = w;
    this.h = h;
  }
  area() {
    return this.w * this.h;
  }
}


console.log(new Circle(3).area()); 
console.log(new Rectangle(5, 6).area()); 

function wait(ms) {
  return new Promise(resolve => {
    setTimeout(resolve, ms);
  });
}

wait(500)
  .then(() => {
    console.log("Half second");
    return wait(1000);
  })
  .then(() => {
    console.log("One more second");
  });

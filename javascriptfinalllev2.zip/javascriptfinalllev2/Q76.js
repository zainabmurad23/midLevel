class Vehicle {
  constructor(brand) {
    this.brand = brand;
  }

  move() {
    console.log(this.brand + " is moving");
  }
}

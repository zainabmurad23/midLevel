function getDataPromise() {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const result = { success: true };
  
      resolve(result);

    }, 1000);
  });
}


getDataPromise()
  .then(data => {
    console.log("Promise resolved:", data);
  })
  .catch(err => {
    console.log("Promise rejected:", err);
  });

function getJSON(url, callback) {
  const xhr = new XMLHttpRequest();
  xhr.open("GET", url);

  xhr.onload = function () {
    if (xhr.status === 200) {
      const data = JSON.parse(xhr.responseText);
      callback(null, data); // لا يوجد خطأ → نرسل البيانات
    } else {
      callback("Request failed with status: " + xhr.status, null);
    }
  };

  xhr.onerror = function () {
    callback("Network error", null);
  };

  xhr.send();
}

const json =
'{"students":[{"name":"A","grade":80},{"name":"B","grade":90}]}';


const data = JSON.parse(json);

let sum = 0;


data.students.forEach(student => {
  sum += student.grade;
});


const average = sum / data.students.length;


console.log("Class average:", average);

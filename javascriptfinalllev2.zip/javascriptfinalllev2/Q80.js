class User {
  constructor(firstName, lastName) {
    this.firstName = firstName;
    this.lastName = lastName;
  }

  get fullName() {
    return `${this.firstName} ${this.lastName}`;
  }

  set fullName(name) {
    const parts = name.split(" ");
    this.firstName = parts[0];
    this.lastName = parts[1];
  }
}


const u = new User("Zeinab", "Ismail");
console.log(u.fullName); 
u.fullName = "Lama Ahmed";
console.log(u.firstName); 

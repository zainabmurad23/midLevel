class Vehicle {
  constructor(brand) {
    this.brand = brand;
  }

  move() {
    console.log(this.brand + " is moving");
  }
}
class Car extends Vehicle {
  honk() {
    console.log(this.brand + " says: Beep!");
  }
}


const myCar = new Car("BMW");
myCar.move(); 
myCar.honk(); 

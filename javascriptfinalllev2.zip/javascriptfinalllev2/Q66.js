function wait(ms) {
  return new Promise(resolve => {
    setTimeout(() => resolve(ms), ms);
  });
}

const task1 = wait(500);
const task2 = wait(1000);
const task3 = wait(1500);

Promise.all([task1, task2, task3])
  .then(() => {
    console.log("All tasks completed");
  })
  .catch(err => {
    console.log("Some task failed:", err);
  });

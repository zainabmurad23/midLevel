function doAfterDelay(message, delay, callback) {
  setTimeout(() => {
    console.log(message);  
    callback();            
  }, delay);
}


doAfterDelay("Hello after 1 second", 1000, () => {
  console.log("Callback called!");
});

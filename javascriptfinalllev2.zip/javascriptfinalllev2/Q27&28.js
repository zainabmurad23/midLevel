const json =
'{"tasks":[{"title":"A","done":false},{"title":"B","done":true}]}';

const data = JSON.parse(json);

data.tasks
  .filter(task => task.done === false)
  .forEach(task => console.log(task.title));

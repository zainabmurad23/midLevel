fetch("./config.json")
  .then(res => res.json())
  .then(config => {
 
    if (config.theme === "dark") {
      document.body.style.backgroundColor = "#222";
      document.body.style.color = "#fff";
    } else {
      document.body.style.backgroundColor = "#fff";
      document.body.style.color = "#000";
    }


    console.log("Language:", config.language);
  })
  .catch(err => console.log("Error loading config:", err));

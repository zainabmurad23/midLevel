async function fetchFromInvalidUrl() {
  try {
    const res = await fetch("https://this-url-does-not-exist.example");
    if (!res.ok) {
      throw new Error("HTTP error: " + res.status);
    }
    const data = await res.json();
    console.log(data);
  } catch (error) {
    console.log("Caught error:", error.message);
  }
}

fetchFromInvalidUrl();

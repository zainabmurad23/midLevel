function getUsersXHR(callback) {
  const xhr = new XMLHttpRequest();
  xhr.open("GET", "https://jsonplaceholder.typicode.com/users");

  xhr.onload = function () {
    const data = JSON.parse(xhr.responseText); 
    callback(data); 

  xhr.send(); 
}}

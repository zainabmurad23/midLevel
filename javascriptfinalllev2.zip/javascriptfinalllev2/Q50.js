fetch("https://reqres.in/api/users", {
  method: "POST",
  headers: {
    "Content-Type": "application/json"
  },
  body: JSON.stringify({
    name: "Test",
    job: "Developer"
  })
})
  .then(res => res.json())
  .then(data => console.log("Response:", data))
  .catch(err => console.log("Network error:", err));

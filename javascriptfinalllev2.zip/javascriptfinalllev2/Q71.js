async function loadUsersAndPosts() {
  try {
    const [usersRes, postsRes] = await Promise.all([
      fetch("https://jsonplaceholder.typicode.com/users"),
      fetch("https://jsonplaceholder.typicode.com/posts")
    ]);

    const [users, posts] = await Promise.all([
      usersRes.json(),
      postsRes.json()
    ]);

    console.log("Users count:", users.length);
    console.log("Posts count:", posts.length);
    console.log(`Loaded ${users.length} users and ${posts.length} posts.`);
  } catch (error) {
    console.log("Error:", error);
  }
}

loadUsersAndPosts();

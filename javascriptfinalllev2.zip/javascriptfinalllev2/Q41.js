function fetchPost(id) {
  fetch(`https://jsonplaceholder.typicode.com/posts/${id}`)
    .then(response => response.json())
    .then(post => {
      const h2 = document.createElement("h2");
      h2.textContent = post.title;

      const p = document.createElement("p");
      p.textContent = post.body;

      document.body.appendChild(h2);
      document.body.appendChild(p);
    })
    .catch(error => console.log(error));
}

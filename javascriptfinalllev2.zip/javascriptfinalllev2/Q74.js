class Rectangle {
  constructor(width, height) {
    this.width = width;
    this.height = height;
  }

  area() {
    return this.width * this.height;
  }
}


const r1 = new Rectangle(5, 10);
const r2 = new Rectangle(3, 7);

console.log(r1.area()); 
console.log(r2.area());

function fetchJSON(url) {
  return fetch(url)
    .then(response => {
      if (!response.ok) {
        throw new Error("HTTP error: " + response.status);
      }
      return response.json();        
    })
    .catch(err => {

      return Promise.reject("Request failed: " + err.message);
    });
}

function loadJSONAndCount(url, callback) {
  const xhr = new XMLHttpRequest();
  xhr.open("GET", url);

  xhr.onload = function () {
    if (xhr.status === 200) {
      const data = JSON.parse(xhr.responseText);

   
      let count;
      if (Array.isArray(data)) {
        count = data.length;
      } else {
        count = Object.keys(data).length;
      }

      callback(null, count); 
    } else {
      callback("Request failed with status: " + xhr.status, null);
    }
  };

  xhr.onerror = function () {
    callback("Network error", null);
  };

  xhr.send();
}


loadJSONAndCount("https://jsonplaceholder.typicode.com/users", (err, count) => {
  if (err) {
    console.log(err);
  } else {
    console.log("Items count:", count);
  }
});

class Counter {
  constructor() {
    this.value = 0;
  }

  increment() {
    this.value++;
    return this; 
  }

  decrement() {
    this.value--;
    return this; 
  }

  log() {
    console.log(this.value);
    return this; 
  }
}


new Counter()
  .increment()
  .increment()
  .log()     
  .decrement()
  .log();  

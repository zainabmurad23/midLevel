const loading = document.createElement("p");
loading.textContent = "Loading...";
document.body.appendChild(loading); 

const xhr = new XMLHttpRequest();
xhr.open("GET", "https://jsonplaceholder.typicode.com/posts");

xhr.onload = function () {
  document.body.removeChild(loading); 

  if (xhr.status === 200) {
    const posts = JSON.parse(xhr.responseText);
    console.log(posts);
  } else {
    console.log("Request failed with status: " + xhr.status);
  }
};

xhr.send(); 

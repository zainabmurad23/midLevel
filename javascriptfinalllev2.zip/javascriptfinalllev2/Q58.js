function step1(callback) {
  setTimeout(() => {
    console.log("Step 1");
    callback(); 
  }, 500);
}

function step2(callback) {
  setTimeout(() => {
    console.log("Step 2");
    callback && callback(); 
  }, 500);
}


step1(() => {
  step2(() => {
    console.log("All steps done");
  });
});

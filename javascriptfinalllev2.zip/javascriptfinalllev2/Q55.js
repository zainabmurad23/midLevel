document.getElementById("loadUser").addEventListener("click", () => {
  const id = document.getElementById("userIdInput").value.trim();
  const info = document.getElementById("userInfo");

  if (!id) {
    info.textContent = "Please enter an ID.";
    return;
  }

  fetch(`https://jsonplaceholder.typicode.com/users/${id}`)
    .then(res => {
      if (!res.ok) {
        throw new Error("HTTP error: " + res.status);
      }
      return res.json();
    })
    .then(user => {
      info.textContent = `${user.name} – ${user.email}`;
    })
    .catch(err => {
      info.textContent = "Error: " + err.message;
    });
});

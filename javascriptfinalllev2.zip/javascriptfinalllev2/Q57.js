function getData(callback) {
  setTimeout(() => {
    const result = { success: true };
    callback(result);
  }, 1000); 
}


getData((data) => {
  console.log("Received:", data);
});

class Rectangle {
  constructor(width, height) {
    this.width = width;
    this.height = height;
  }

  area() {
    return this.width * this.height;
  }

  static fromSquare(size) {
    return new Rectangle(size, size);
  }
}


const square = Rectangle.fromSquare(4);
console.log(square.area()); 


document.getElementById("loadComments").addEventListener("click", () => {
  fetch("https://jsonplaceholder.typicode.com/comments?postId=1")
    .then(res => res.json())
    .then(comments => {
      const container = document.getElementById("comments");
      container.innerHTML = ""; 

      comments.forEach(c => {
        const div = document.createElement("div");
        div.innerHTML = `<strong>${c.email}</strong><p>${c.body}</p>`;
        container.appendChild(div);
      });
    })
    .catch(err => console.log("Network error:", err));
});

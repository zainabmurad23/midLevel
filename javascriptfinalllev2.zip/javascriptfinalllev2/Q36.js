const xhr = new XMLHttpRequest();

xhr.open("POST", "https://jsonplaceholder.typicode.com/posts");
xhr.setRequestHeader("Content-Type", "application/json");

xhr.onload = function () {
  console.log(xhr.responseText); 
};

const data = {
  title: "New Post",
  body: "Content",
  userId: 1
};

xhr.send(JSON.stringify(data));

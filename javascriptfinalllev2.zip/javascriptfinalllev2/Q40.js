fetch("https://jsonplaceholder.typicode.com/todos?userId=1")
  .then(response => response.json())
  .then(todos => {
    const ul = document.createElement("ul");

    todos
      .filter(todo => todo.completed === true) 
      .forEach(todo => {
        const li = document.createElement("li");
        li.textContent = "✔️ " + todo.title; 
        li.style.color = "green"; 
        ul.appendChild(li);
      });

    document.body.appendChild(ul);
  })
  .catch(error => console.log(error));

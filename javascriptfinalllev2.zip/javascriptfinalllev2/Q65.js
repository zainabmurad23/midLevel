const first = Promise.resolve(10);

first
  .then(num => num * 2)          
  .then(result => {              
    console.log("Final result:", result); // 20
  });

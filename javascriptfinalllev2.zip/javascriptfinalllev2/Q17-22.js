const user = {
  username: "admin",
  password: "1234",
  role: "superadmin"
};
const json = JSON.stringify(user, (key, value) => {
  if (key === "password") {
    return undefined; 
  }
  return value; 
});

console.log(json);

function saveUser(userObj) {
  const json = JSON.stringify(userObj);
  localStorage.setItem("user", json);
}

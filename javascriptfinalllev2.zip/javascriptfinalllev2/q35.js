const xhr = new XMLHttpRequest();
xhr.open("GET", "https://jsonplaceholder.typicode.com/posts");

xhr.onload = function () {
  if (xhr.status === 200) {
    const posts = JSON.parse(xhr.responseText);

    
    const ul = document.createElement("ul");


    posts.slice(0, 5).forEach(post => {
      const li = document.createElement("li");
      li.textContent = post.title;
      ul.appendChild(li);
    });

   
    document.body.appendChild(ul);
  } else {
    console.log("Request failed with status: " + xhr.status);
  }
};

xhr.send();

fetch("https://jsonplaceholder.typicode.com/users")
  .then(response => response.json()) 
  .then(users => {
    console.log("Number of users:", users.length);     
    console.log("First user name:", users[0].name);     
  })
  .catch(error => console.log(error)); 

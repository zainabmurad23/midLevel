function getUser(id) {
  return new Promise(resolve => {
    setTimeout(() => {
      const user = { id, name: "Test User", email: "test@example.com" };
      resolve(user);
    }, 1000); 
  });
}


getUser(5).then(user => {
  console.log(user);
});

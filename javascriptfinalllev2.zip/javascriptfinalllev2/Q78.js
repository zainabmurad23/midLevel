class Vehicle {
  constructor(brand) {
    this.brand = brand;
  }
}

class Car extends Vehicle {
  constructor(brand, model) {
    super(brand); 
    this.model = model;
  }

  info() {
    console.log(`${this.brand} ${this.model}`);
  }
}


const myCar = new Car("Toyota", "Corolla");
myCar.info(); // Toyota Corolla
